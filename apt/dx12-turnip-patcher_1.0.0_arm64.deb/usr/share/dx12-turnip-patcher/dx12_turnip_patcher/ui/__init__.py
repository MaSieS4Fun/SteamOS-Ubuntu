"""GTK window."""
