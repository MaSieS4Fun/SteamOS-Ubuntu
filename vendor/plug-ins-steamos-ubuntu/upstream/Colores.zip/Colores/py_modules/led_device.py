import logging
import os
import re


logger = logging.getLogger(__name__)


def _clamp8(value):
    return max(0, min(255, int(value)))


def _clamp_pct(value):
    return max(0, min(100, int(value)))


def apply_gain(color, gains):
    return tuple(_clamp8(round(c * gains[i])) for i, c in enumerate(color))


class LedDevice:
    led_path = None
    last_error = None

    @property
    def available(self):
        return False

    def supports_per_zone(self):
        return False

    def supports_hardware_effects(self):
        return False

    def supports_sleep_charging_indicator(self):
        return False

    def set_sleep_charging_indicator(self, enabled):
        return False

    def reconnect(self):
        return self.available

    def _level(self, brightness, power):
        return round((_clamp_pct(brightness) / 100) * self._max_brightness) if power else 0

    def _fit(self, zone_colors):
        colors = list(zone_colors) or [(0, 0, 0)]
        if len(colors) < self._zones:
            colors += [colors[-1]] * (self._zones - len(colors))
        return colors[: self._zones]

    def invalidate(self):
        # Drop any cached "already in this mode" state so the next apply re-sends the
        # full init/commit sequence. No-op for a plain sysfs device with no latch.
        return None

    def apply_zones(self, zone_colors, brightness, power):
        return False

    def apply_solid(self, color, brightness, power):
        return False

    def apply_hardware_effect(self, effect_id, color, speed, brightness, power):
        return False


class NullDevice(LedDevice):
    pass


class ApexRgbDevice(LedDevice):
    def __init__(self, hid_device, sysfs_device):
        self._devices = {"hid": hid_device, "sysfs": sysfs_device}
        self.route = "hid" if self._is_available(hid_device) else "sysfs"
        self.last_error = None
        logger.info("Apex RGB route selected: %s", self.route)

    @staticmethod
    def _is_available(device):
        try:
            return bool(device and device.available)
        except Exception:
            return False

    @property
    def available(self):
        return self._is_available(self._devices[self.route])

    @property
    def led_path(self):
        return getattr(self._devices[self.route], "led_path", None)

    def supports_per_zone(self):
        device = self._devices[self.route]
        return bool(device and device.supports_per_zone())

    def supports_hardware_effects(self):
        return False

    def invalidate(self):
        for device in self._devices.values():
            if device:
                device.invalidate()

    def reconnect(self):
        if self._activate("hid", reconnect=True):
            self.last_error = None
            logger.info("Apex RGB HID route recovered")
            return True
        if self._activate("sysfs", reconnect=True):
            return True
        return False

    def apply_zones(self, zone_colors, brightness, power):
        colors = list(zone_colors)
        primary = self.route
        if self._apply(self._devices[primary], colors, brightness, power):
            self.last_error = None
            return True

        primary_error = self._route_error(primary, "write failed")
        fallback = "sysfs" if primary == "hid" else "hid"
        logger.warning(
            "Apex RGB %s route failed (%s), switching to %s",
            primary,
            primary_error,
            fallback,
        )
        if self._activate(fallback, reconnect=fallback == "hid"):
            if self._apply(self._devices[fallback], colors, brightness, power):
                self.last_error = None
                logger.info("Apex RGB route switched to %s", fallback)
                return True

        fallback_error = self._route_error(fallback, "unavailable")
        self.last_error = f"{primary}: {primary_error}; {fallback}: {fallback_error}"
        logger.error("Apex RGB routes failed: %s", self.last_error)
        return False

    def apply_solid(self, color, brightness, power):
        return self.apply_zones([tuple(color)], brightness, power)

    def _activate(self, route, reconnect=False):
        device = self._devices.get(route)
        if not device:
            return False
        try:
            if reconnect and not device.reconnect():
                return False
            device.invalidate()
        except Exception as exc:
            device.last_error = f"{type(exc).__name__}"
            return False
        self.route = route
        return True

    def _route_error(self, route, fallback):
        return getattr(self._devices.get(route), "last_error", None) or fallback

    @staticmethod
    def _apply(device, colors, brightness, power):
        try:
            return bool(device and device.apply_zones(colors, brightness, power))
        except Exception as exc:
            if device:
                device.last_error = type(exc).__name__
            return False


class SysfsRgbDevice(LedDevice):
    def __init__(self, led_path, zones=1, max_brightness=255, color_order="rgb", index_format="hex", color_correction=(1.0, 1.0, 1.0), latch=None, per_zone=True):
        self._led_path = led_path
        self._zones = max(1, zones)
        self._max_brightness = max_brightness or 255
        self._color_order = color_order
        self._index_format = index_format
        self._color_correction = tuple(color_correction)
        self.last_error = None
        self._intensity_path = os.path.join(led_path, "multi_intensity") if led_path else None
        self._brightness_path = os.path.join(led_path, "brightness") if led_path else None
        self._has_intensity = bool(self._intensity_path) and os.path.exists(self._intensity_path)
        self._has_brightness = bool(self._brightness_path) and os.path.exists(self._brightness_path)
        self._channel_maxima = self._read_channel_maxima()
        self._packed_maxima_compatible = self._packed_maxima_are_compatible()
        self._latch = [(os.path.join(led_path, attr), value) for attr, value in (latch or [])] if led_path else []
        self._latched = False
        self._per_zone = bool(per_zone)

    @property
    def available(self):
        return bool(self._led_path) and self._packed_maxima_compatible

    @property
    def led_path(self):
        return self._led_path

    def supports_per_zone(self):
        return self._per_zone

    def invalidate(self):
        self._latched = False

    def reconnect(self):
        self._latched = False
        return self.available

    def _apply_latch(self):
        if self._latched or not self._latch:
            return
        if not all(os.path.exists(path) for path, _ in self._latch):
            return
        for path, value in self._latch:
            with open(path, "w") as handle:
                handle.write(value)
        self._latched = True

    def _order(self, color):
        r, g, b = apply_gain(color, self._color_correction)
        channels = {"r": r, "g": g, "b": b}
        order = self._color_order if set(self._color_order) == set("rgb") else "rgb"
        return tuple(channels[channel] for channel in order)

    def _read_channel_maxima(self):
        if not self._led_path or self._index_format != "decimal":
            return None
        try:
            with open(os.path.join(self._led_path, "multi_max_intensity")) as handle:
                values = tuple(int(value) for value in handle.read().split())
        except (OSError, ValueError):
            return None
        if len(values) != self._zones * 3 or any(value <= 0 for value in values):
            return None
        return values

    def _packed_maxima_are_compatible(self):
        if not self._led_path or self._index_format != "packed_decimal":
            return True
        path = os.path.join(self._led_path, "multi_max_intensity")
        if not os.path.exists(path):
            return True
        try:
            with open(path) as handle:
                values = tuple(int(value, 0) for value in handle.read().split())
        except (OSError, ValueError):
            return False
        return len(values) == self._zones and all(value >= 0xFFFFFF for value in values)

    def _format_zone(self, color, zone):
        channels = self._order(color)
        if self._channel_maxima:
            offset = zone * 3
            maxima = self._channel_maxima[offset : offset + 3]
            channels = tuple(round(channel * maximum / 255) for channel, maximum in zip(channels, maxima))
        r, g, b = channels
        if self._index_format == "decimal":
            return f"{r} {g} {b}"
        if self._index_format == "packed_decimal":
            return str((r << 16) | (g << 8) | b)
        return f"0x{r:02x}{g:02x}{b:02x}"

    def apply_zones(self, zone_colors, brightness, power):
        self.last_error = None
        if not self._led_path:
            self.last_error = "no led path"
            return False
        level = self._level(brightness, power)
        try:
            self._apply_latch()
        except OSError as error:
            self.last_error = str(error)
            self._latched = False
            return False
        try:
            if self._has_intensity:
                values = " ".join(self._format_zone(color, zone) for zone, color in enumerate(self._fit(zone_colors)))
                with open(self._intensity_path, "w") as handle:
                    handle.write(values)
            if self._has_brightness:
                with open(self._brightness_path, "w") as handle:
                    handle.write(str(level))
            return True
        except OSError as error:
            self.last_error = str(error)
            return False

    def apply_solid(self, color, brightness, power):
        return self.apply_zones([tuple(color)], brightness, power)


PORTAL_LED_NAMES = tuple(
    [f"rgb:l{index}" for index in range(1, 5)]
    + [f"rgb:r{index}" for index in range(1, 5)]
)


def discover_portal_leds(leds_dir):
    nodes = []
    for name in PORTAL_LED_NAMES:
        path = os.path.join(leds_dir, name)
        try:
            with open(os.path.join(path, "multi_index")) as handle:
                channels = handle.read().strip().lower().split()
        except OSError:
            return []
        required = ("multi_intensity", "brightness", "max_brightness")
        if channels != ["blue", "green", "red"] or not all(
            os.path.exists(os.path.join(path, filename)) for filename in required
        ):
            return []
        nodes.append(path)
    return nodes


class MultiSysfsRgbDevice(LedDevice):
    def __init__(self, node_paths, color_order="rgb", color_correction=(1.0, 1.0, 1.0), groups=None):
        self._nodes = list(node_paths)
        # Per-zone needs a profile: the LED order inside a ring is per machine.
        self._groups = [list(group) for group in groups] if groups else None
        self._zones = len(self._groups) if self._groups else len(self._nodes)
        self._max_brightness = 255
        orders = [color_order] * len(self._nodes) if isinstance(color_order, str) else list(color_order)
        self._devices = [
            SysfsRgbDevice(
                path,
                zones=1,
                max_brightness=self._node_max(path),
                color_order=order,
                index_format="decimal",
                color_correction=color_correction,
            )
            for path, order in zip(self._nodes, orders)
        ]
        self.last_error = None

    @staticmethod
    def _node_max(path):
        try:
            with open(os.path.join(path, "max_brightness")) as handle:
                value = int(handle.read().strip())
        except (OSError, ValueError):
            return 255
        return value if value > 0 else 255

    @property
    def available(self):
        return bool(self._devices) and all(device.available for device in self._devices)

    @property
    def led_path(self):
        return self._nodes[0] if self._nodes else None

    def supports_per_zone(self):
        return self._groups is not None

    def reconnect(self):
        return self.available

    def invalidate(self):
        for device in self._devices:
            device.invalidate()

    def _write(self, index, color, brightness, power):
        device = self._devices[index]
        if device.apply_zones([tuple(color)], brightness, power):
            return True
        self.last_error = device.last_error or "sysfs write failed"
        return False

    def apply_zones(self, zone_colors, brightness, power):
        if self._groups is None:
            return self.apply_solid((list(zone_colors) or [(0, 0, 0)])[0], brightness, power)
        self.last_error = None
        results = [
            self._write(index, color, brightness, power)
            for color, group in zip(self._fit(zone_colors), self._groups)
            for index in group
        ]
        return all(results)

    def apply_solid(self, color, brightness, power):
        self.last_error = None
        return all([self._write(index, color, brightness, power) for index in range(len(self._devices))])


class HpOmenRgbDevice(LedDevice):
    def __init__(self, platform_path):
        self._platform_path = platform_path
        self._zone_paths = [os.path.join(platform_path, f"zone{index}") for index in range(8)]
        self._brightness_path = os.path.join(platform_path, "brightness")
        self._zones = 8
        self._max_brightness = 1
        self.last_error = None

    @property
    def available(self):
        return bool(self._platform_path) and all(
            os.path.isfile(path) for path in [*self._zone_paths, self._brightness_path]
        )

    @property
    def led_path(self):
        return self._platform_path

    def supports_per_zone(self):
        return False

    def reconnect(self):
        return self.available

    def apply_zones(self, zone_colors, brightness, power):
        colors = list(zone_colors) or [(0, 0, 0)]
        return self.apply_solid(colors[0], brightness, power)

    def apply_solid(self, color, brightness, power):
        self.last_error = None
        r, g, b = (_clamp8(channel) for channel in color)
        value = f"{r:02X}{g:02X}{b:02X}"
        enabled = "1" if power and _clamp_pct(brightness) > 0 else "0"
        try:
            for path in self._zone_paths:
                with open(path, "w") as handle:
                    handle.write(value)
            with open(self._brightness_path, "w") as handle:
                handle.write(enabled)
            return True
        except OSError as error:
            self.last_error = str(error)
            return False


_VALVE_NODE_RE = re.compile(r"^valve-leds\[(\d+)\]$")


def discover_valve_leds(leds_dir):
    try:
        entries = os.listdir(leds_dir)
    except OSError:
        return []
    nodes = []
    for name in entries:
        match = _VALVE_NODE_RE.match(name)
        if match:
            nodes.append((int(match.group(1)), os.path.join(leds_dir, name)))
    nodes.sort(key=lambda item: item[0])
    return [path for _, path in nodes]


class ValveLedsDevice(LedDevice):
    def __init__(self, node_paths, max_brightness=255, color_correction=(1.0, 1.0, 1.0), reverse=False):
        self._nodes = list(node_paths)
        self._write_order = list(reversed(self._nodes)) if reverse else list(self._nodes)
        self._zones = len(self._nodes)
        self._max_brightness = max_brightness or 255
        self._color_correction = tuple(color_correction)
        self.last_error = None
        self._ctrl = self._nodes[0] if self._nodes else None
        self._intensity_paths = [os.path.join(p, "multi_intensity") for p in self._write_order]
        self._startup_paths = [os.path.join(p, "multi_intensity_startup") for p in self._write_order]
        self._scale_path = os.path.join(self._ctrl, "brightness_scale") if self._ctrl else None
        self._brightness_startup_path = os.path.join(self._ctrl, "brightness_startup") if self._ctrl else None
        self._manual_set = False
        self._last_level = None
        self._last_intensity = None

    @property
    def available(self):
        return bool(self._nodes)

    @property
    def led_path(self):
        return self._ctrl

    def supports_per_zone(self):
        return True

    def supports_hardware_effects(self):
        return False

    def invalidate(self):
        self._manual_set = False
        self._last_level = None

    @staticmethod
    def _write(path, value):
        with open(path, "w") as handle:
            handle.write(value)

    def _ensure_manual(self):
        if self._manual_set or not self._ctrl:
            return
        try:
            self._write(os.path.join(self._ctrl, "enabled"), "1")
        except OSError:
            pass
        self._write(os.path.join(self._ctrl, "effect"), "manual")
        for path in self._nodes:
            try:
                self._write(os.path.join(path, "brightness"), str(self._max_brightness))
            except OSError:
                pass
        self._manual_set = True

    def apply_zones(self, zone_colors, brightness, power):
        self.last_error = None
        if not self._nodes:
            self.last_error = "no valve-leds nodes"
            return False
        level = self._level(brightness, power)
        try:
            self._ensure_manual()
            values = []
            for path, color in zip(self._intensity_paths, self._fit(zone_colors)):
                r, g, b = apply_gain(color, self._color_correction)
                text = f"{r} {g} {b}"
                self._write(path, text)
                values.append(text)
            self._last_intensity = values
            if level != self._last_level:
                self._write(self._scale_path, str(level))
                self._last_level = level
            return True
        except OSError as error:
            self.last_error = str(error)
            self._manual_set = False
            self._last_level = None
            return False

    def apply_solid(self, color, brightness, power):
        return self.apply_zones([tuple(color)] * self._zones, brightness, power)

    def save_startup(self):
        if not self._nodes or self._last_intensity is None:
            return False
        try:
            for path, value in zip(self._startup_paths, self._last_intensity):
                self._write(path, value)
            if self._last_level is not None and self._brightness_startup_path:
                self._write(self._brightness_startup_path, str(self._last_level))
            return True
        except OSError as error:
            self.last_error = str(error)
            return False

    def read_startup(self):
        if not self._nodes:
            return None
        try:
            intensities = [open(path).read().strip() for path in self._startup_paths]
            level = open(self._brightness_startup_path).read().strip()
            return {"intensities": intensities, "level": level}
        except OSError:
            return None

    def restore_startup(self, saved):
        if not self._nodes or not saved:
            return False
        try:
            for path, value in zip(self._startup_paths, saved.get("intensities", [])):
                self._write(path, value)
            level = saved.get("level")
            if level is not None and self._brightness_startup_path:
                self._write(self._brightness_startup_path, str(level))
            return True
        except OSError as error:
            self.last_error = str(error)
            return False
